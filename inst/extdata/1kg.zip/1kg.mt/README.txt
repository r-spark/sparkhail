This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.12-9409c0635781
  Created at 2019/04/24 10:49:12